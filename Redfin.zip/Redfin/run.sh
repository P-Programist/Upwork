# Define Absolute Path
# SCRIPT=$(readlink -f $0)
# SCRIPTPATH=`dirname $SCRIPT`

# Remove or put `#` symbol on the line below to comment out this line
# /Users/umairrizwan/Downloads/Redfin/drivers.sh

python3 /Users/umairrizwan/Downloads/Redfin/main.py